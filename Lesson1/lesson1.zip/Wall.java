package Lesson1.HW1;

public class Wall extends Barrier{

    public Wall(double lengthPath) {
        super(lengthPath);
    }

}
