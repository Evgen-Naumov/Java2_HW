package Lesson1.HW1;

public abstract class Barrier {
    double LengthPath;

    public Barrier(double PathBarrier) {
        LengthPath = PathBarrier;
    }

}
