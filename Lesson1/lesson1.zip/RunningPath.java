package Lesson1.HW1;

public class RunningPath extends Barrier{

    public RunningPath(double lengthPath) {
        super(lengthPath);
    }

}
