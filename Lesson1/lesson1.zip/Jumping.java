package Lesson1.HW1;

public interface Jumping extends Skills{
    boolean doJum(double JumpPath);
    void canJump();
}
