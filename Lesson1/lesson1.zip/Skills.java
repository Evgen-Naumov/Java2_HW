package Lesson1.HW1;

public interface Skills {
}
