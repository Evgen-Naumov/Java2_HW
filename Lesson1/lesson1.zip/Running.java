package Lesson1.HW1;

public interface Running extends  Skills{
   boolean doRun(double RunPath);
   void canRun();
}
